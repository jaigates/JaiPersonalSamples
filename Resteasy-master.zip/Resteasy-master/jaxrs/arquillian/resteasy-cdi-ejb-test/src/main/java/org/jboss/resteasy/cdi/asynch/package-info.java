/**
 * This package (along with @see org.jboss.resteasy.test.cdi.asynch) tests JAX-RS and EJB
 * asynchronous processing.
 * 
 * @see org.jboss.resteasy.package-info.java
*/
package org.jboss.resteasy.cdi.asynch;
