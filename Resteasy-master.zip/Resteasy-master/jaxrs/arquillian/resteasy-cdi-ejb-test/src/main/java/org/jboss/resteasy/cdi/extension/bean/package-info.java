/**
 * This package (along with @see org.jboss.resteasy.test.cdi.extension.bean) introduces an
 * application defined implementation of javax.enterprise.inject.spi.Bean.
 * 
 * @see org.jboss.resteasy.package-info.java
*/
package org.jboss.resteasy.cdi.extension.bean;
