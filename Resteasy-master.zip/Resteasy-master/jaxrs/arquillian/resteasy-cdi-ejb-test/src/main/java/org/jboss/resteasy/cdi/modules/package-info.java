/**
 * This package (along with @see org.jboss.resteasy.test.cdi.modules) tests injection
 * of beans into JAX-RS resources across various jar, ejb-jar, war, and ear boundaries.
 * 
 * @see org.jboss.resteasy.package-info.java
 */
package org.jboss.resteasy.cdi.modules;
