package org.jboss.resteasy.cdi.injection;

import javax.enterprise.context.Dependent;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Dec 4, 2012
 */
@Dependent
@ScopeInheritingStereotype
public class StereotypedDependentScope
{

}
