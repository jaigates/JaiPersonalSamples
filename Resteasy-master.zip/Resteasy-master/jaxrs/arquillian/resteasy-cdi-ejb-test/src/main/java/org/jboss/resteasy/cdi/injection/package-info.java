/**
 * This package (along with @see org.jboss.resteasy.test.cdi.injection) tests injection
 * into JAX-RS components.
 * 
 * @see org.jboss.resteasy.package-info.java
 */
package org.jboss.resteasy.cdi.injection;
