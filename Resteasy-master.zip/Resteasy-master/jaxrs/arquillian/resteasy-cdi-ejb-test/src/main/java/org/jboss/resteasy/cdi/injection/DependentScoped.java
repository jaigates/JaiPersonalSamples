package org.jboss.resteasy.cdi.injection;

import javax.enterprise.context.Dependent;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright May 24, 2012
 */
@Dependent
public class DependentScoped
{

}

