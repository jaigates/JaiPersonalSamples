package org.jboss.resteasy.cdi.extension.bean;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Jun 23, 2012
 */
@Boston
public class BostonlLeaf
{

}

