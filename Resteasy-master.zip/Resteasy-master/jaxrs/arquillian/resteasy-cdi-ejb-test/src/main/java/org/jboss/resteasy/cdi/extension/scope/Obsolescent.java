package org.jboss.resteasy.cdi.extension.scope;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Jun 12, 2012
 */
public interface Obsolescent
{

}
