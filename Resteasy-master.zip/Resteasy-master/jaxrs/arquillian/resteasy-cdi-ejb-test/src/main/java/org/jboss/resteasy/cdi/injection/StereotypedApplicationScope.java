package org.jboss.resteasy.cdi.injection;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Dec 4, 2012
 */
@ScopeInheritingStereotype
public class StereotypedApplicationScope
{
   public void test()
   {
   }
}
