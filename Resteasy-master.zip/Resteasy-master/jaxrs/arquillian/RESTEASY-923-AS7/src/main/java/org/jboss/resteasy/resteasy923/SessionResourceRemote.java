package org.jboss.resteasy.resteasy923;

import javax.ejb.Remote;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Mar 26, 2014
 */
@Remote
public interface SessionResourceRemote extends SessionResourceParent
{
}