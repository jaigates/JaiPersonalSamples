package org.jboss.resteasy.resteasy923;

import javax.ejb.Local;

/**
 * 
 * @author <a href="ron.sigal@jboss.com">Ron Sigal</a>
 * @version $Revision: 1.1 $
 *
 * Copyright Mar 26, 2014
 */
@Local
public interface SessionResourceLocal extends SessionResourceParent
{
}