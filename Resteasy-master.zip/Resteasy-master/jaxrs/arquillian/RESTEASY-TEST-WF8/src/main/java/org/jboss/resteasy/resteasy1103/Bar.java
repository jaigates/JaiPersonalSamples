package org.jboss.resteasy.resteasy1103;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Bar {
  private String _s;
  public String getS() {
    return _s;
  }
  public void setS(String s) {
    _s = s;
  }
}
