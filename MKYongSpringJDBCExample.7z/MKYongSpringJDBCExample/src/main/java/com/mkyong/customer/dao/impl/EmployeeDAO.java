package com.mkyong.customer.dao.impl;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.TEST0117.Test0117SP;
import com.mkyong.customer.dao.EmployeeDAOI;

public class EmployeeDAO implements EmployeeDAOI {

	private JdbcTemplate jdbcTemplate;
	private Test0117SP sproc;

	public void setDataSource(DataSource source) {
		this.jdbcTemplate = new JdbcTemplate(source);
		this.sproc = new Test0117SP(jdbcTemplate.getDataSource());
	}

	public String getEmployeeName(int emp_id) {
		 Map<String, Object> execute = sproc.execute(emp_id);
		
		 
		 return "";
	}

}
